// Copyright (c) Jupyter Development Team.
// Distributed under the terms of the Modified BSD License.

describe('foo', () => {
  describe('bar', () => {
    it('should pass', () => {
      expect(true).toBe(true);
    });
  });
});
