import '@jupyterlab/filebrowser/style/index.js';

import './base.css';
